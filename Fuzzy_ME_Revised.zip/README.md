# Fuzzy_ME_Revised

Optimized Implementation of Fuzzy Identity-based Matchmaking Encryption
