# Fuzzy_IB_ME

Optimized Implementation of Fuzzy Identity-based Matchmaking Encryption
